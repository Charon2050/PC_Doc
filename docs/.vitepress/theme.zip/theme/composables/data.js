import { useData as useData$ } from 'vitepress';
export const useData = useData$;
